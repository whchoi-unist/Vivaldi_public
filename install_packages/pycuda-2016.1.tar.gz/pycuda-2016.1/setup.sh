sudo apt-get install python-numpy -y
sudo apt-get install build-essential python-dev python-setuptools libboost-python-dev libboost-thread-dev -y
./configure.py --cuda-root=/usr/local/cuda --cudadrv-lib-dir=/usr/lib/x86_64-linux-gnu --boost-inc-dir=/usr/include --boost-lib-dir=/usr/lib --boost-python-libname=boost_python --boost-thread-libname=boost_thread --no-use-shipped-boost
make -j 4
sudo python setup.py install
