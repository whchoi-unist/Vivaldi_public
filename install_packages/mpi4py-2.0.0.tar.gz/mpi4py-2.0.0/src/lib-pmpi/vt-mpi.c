#include "vt.h"
char pympi_pmpi_name[] = "vt-mpi";
